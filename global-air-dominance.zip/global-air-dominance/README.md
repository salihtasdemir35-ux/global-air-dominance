# Global Air Dominance – Hava Harp Stratejisi (Android)

Gerçek zamanlı hava harp strateji oyunu: uçak, seyir ve balistik füze, SİHA ve kamikaze İHA sürüleri gönder; karıştırma uçaklarıyla radarları kör et. Önleyicilerin maliyeti hesaplanır, hamleler kaydedilir ve en iyi oyunlar tekrar izlenebilir. Oyun başında harekât planı kurulur, silahlar haritadaki üs ve rampalardan menzilleri görülerek gönderilir. Türkçe ve İngilizce. Tamamen çevrim dışı çalışır. (Harekât planı)

## Klasörler
- `www/` – oyunun kendisi (index.html ve yazı tipleri)
- `assets/` – uygulama simgesi ve açılış ekranı kaynakları (Android simgeleri bunlardan otomatik üretilir)
- `.github/workflows/android.yml` – GitHub Actions ile APK derleme dosyası
- `package.json`, `capacitor.config.json` – Capacitor 7 ayarları (paket adı: com.globalairdominance.app)

## GitHub ile APK alma
1. GitHub’da yeni bir depo açın ve “Add a README file” kutusunu işaretleyin.
2. Add file → Upload files ile bu zip dosyasını olduğu gibi yükleyin ve Commit changes deyin.
3. Add file → Create new file ile adı `.github/workflows/android.yml` olan bir dosya oluşturun, içine `android.yml` dosyasının içeriğini yapıştırın ve kaydedin.
4. Actions sekmesinde “Android APK” çalışmasının yeşil tik almasını bekleyin (yaklaşık 6–10 dakika).
5. Çalışmayı açın, Artifacts bölümünden `GlobalAirDominance-APK` dosyasını indirin, içinden `app-debug.apk` çıkar.
6. APK’yı telefona aktarıp kurun (bilinmeyen kaynaklardan yüklemeye izin vermeniz gerekir).

Güncelleme için aynı adlı yeni zip dosyasını yükleyin; derleme kendiliğinden yeniden başlar. Depoda tek bir zip dosyası bulunmalıdır.

## Notlar
- Üretilen APK hata ayıklama (debug) imzalıdır; telefona doğrudan kurulabilir. Google Play için imzalı AAB ayrıca hazırlanmalıdır.
- Geri tuşu açık paneli kapatır; oyun sırasında oyunu duraklatıp ana menüye döner.
